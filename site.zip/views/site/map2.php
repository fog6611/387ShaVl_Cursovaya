<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Второй этаж';
?>
<div>
    <h1><?= Html::encode($this->title) ?></h1>
</div>

<div class="row">
    <div class="col-md-9">
        <img src="../../img/2floor.png" width="100%">
    </div>
    <div class="col-md-3">
        <?php foreach ($secondFloorCabinets as $currentCabinet) {
            print '
                <div class="dropdown">
                    <button class="accordion">Кабинет '.$currentCabinet['cabinetNumber'].'
                    </button>
                <div class="panel h" style="max-height: 0px;">
                    <p>'.$currentCabinet['cabinetDesc'].'</p>
                    </div>
                </div>';
        } 
        unset($currentCabinet)?>
    </div>
</div>
