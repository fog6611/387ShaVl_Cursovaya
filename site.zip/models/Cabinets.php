<?php

namespace app\models;

use Yii\db\ActiveRecord;

/**
 * This is the model class for table "Cabinets".
 *
 * @property int $id
 * @property int $cabinetFloor Этаж кабинета
 * @property int $cabinetNumber Номер кабинета
 * @property string $cabinetDesc Описание кабинета
 */
class Cabinets extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Cabinets';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cabinetFloor', 'cabinetNumber', 'cabinetDesc'], 'required'],
            [['cabinetFloor', 'cabinetNumber'], 'integer'],
            [['cabinetDesc'], 'string'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'cabinetFloor' => 'Cabinet Floor',
            'cabinetNumber' => 'Cabinet Number',
            'cabinetDesc' => 'Cabinet Desc',
        ];
    }
}
